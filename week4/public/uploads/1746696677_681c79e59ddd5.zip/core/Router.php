<?php
class Router {
    public static function route($uri) {
        require_once __DIR__ . '/../routes.php';
    }
}
?>