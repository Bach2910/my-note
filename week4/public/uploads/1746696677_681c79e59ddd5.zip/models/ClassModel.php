<?php
require_once 'config/Database.php';
class ClassModel {
    public static function all() {
        $stmt = Database::getConnection()->query("SELECT * FROM classes");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public static function find($id) {
        $stmt = Database::getConnection()->prepare("SELECT * FROM classes WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public static function create($name) {
        $stmt = Database::getConnection()->prepare("INSERT INTO classes (name) VALUES (?)");
        return $stmt->execute([$name]);
    }
    public static function update($id, $name) {
        $stmt = Database::getConnection()->prepare("UPDATE classes SET name = ? WHERE id = ?");
        return $stmt->execute([$name, $id]);
    }
    public static function delete($id) {
        $stmt = Database::getConnection()->prepare("DELETE FROM classes WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>