<?php
require_once 'config/Database.php';
class Student {
    public static function all() {
        $stmt = Database::getConnection()->query("SELECT * FROM students");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public static function find($id) {
        $stmt = Database::getConnection()->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public static function create($name) {
        $stmt = Database::getConnection()->prepare("INSERT INTO students (name) VALUES (?)");
        return $stmt->execute([$name]);
    }
    public static function update($id, $name) {
        $stmt = Database::getConnection()->prepare("UPDATE students SET name = ? WHERE id = ?");
        return $stmt->execute([$name, $id]);
    }
    public static function delete($id) {
        $stmt = Database::getConnection()->prepare("DELETE FROM students WHERE id = ?");
        return $stmt->execute([$id]);
    }
    public static function assignClass($studentId, $classId) {
        $stmt = Database::getConnection()->prepare("INSERT INTO student_classes (student_id, class_id) VALUES (?, ?)");
        return $stmt->execute([$studentId, $classId]);
    }
    public static function getClasses($studentId) {
        $stmt = Database::getConnection()->prepare("SELECT classes.name FROM classes INNER JOIN student_classes ON classes.id = student_classes.class_id WHERE student_classes.student_id = ?");
        $stmt->execute([$studentId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>