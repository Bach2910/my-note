<?php
require_once 'controllers/StudentController.php';
require_once 'controllers/ClassController.php';

switch ($uri) {
    case '/':
    case '/students':
        (new StudentController)->index();
        break;
    case '/students/create':
        (new StudentController)->create();
        break;
    case '/students/store':
        (new StudentController)->store();
        break;
    case '/students/edit':
        (new StudentController)->edit();
        break;
    case '/students/update':
        (new StudentController)->update();
        break;
    case '/students/delete':
        (new StudentController)->delete();
        break;
    case '/students/assign':
        (new StudentController)->assign();
        break;
    case '/students/storeAssign':
        (new StudentController)->storeAssign();
        break;
    case '/classes':
        (new ClassController)->index();
        break;
    case '/classes/create':
        (new ClassController)->create();
        break;
    case '/classes/store':
        (new ClassController)->store();
        break;
    case '/classes/edit':
        (new ClassController)->edit();
        break;
    case '/classes/update':
        (new ClassController)->update();
        break;
    case '/classes/delete':
        (new ClassController)->delete();
        break;
    default:
        echo "404 Not Found";
        break;
}
?>